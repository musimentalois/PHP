<?php 
 class Student_model extends CI_Model {
    function __construct(){
        $this->primary_key = "studentId";
        $this->table_name = "student"
    }
 }





?>